package com.toothless7788.java.internshipscraper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InternshipScraperDaoApplication {

	public static void main(String[] args) {
		SpringApplication.run(InternshipScraperDaoApplication.class, args);
	}

}
