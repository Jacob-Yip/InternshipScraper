package com.toothless7788.java.internshipscraper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InternshipScraperDaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
